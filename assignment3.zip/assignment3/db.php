<?php

    $db = "a3003624_scp";
    $user = "a3003624_scpuser";
    $pwd = "Toiohomai1234";
    
    $connection = new mysqli('localhost', $user, $pwd, $db);
    
    $record = $connection->query("select * from pages") or die($connection->error());
    
    if(isset($_POST['submit']))
    {
        $pg = $_POST['pg'];
        $h1 = $_POST['h1'];
        $h2 = $_POST['h2'];
        $p1 = htmlspecialchars($_POST['p1']);
        $p1 = $connection->real_escape_string($p1);
        $p2 = htmlspecialchars($_POST['p2']);
        $p2 = $connection->real_escape_string($p2);
        $images = $_POST['images'];
        
        $sql = "insert into pages(pg, h1, h2, p1, p2, images)
        values('$pg', '$h1', '$h2', '$p1', '$p2', '$images')";
        
        if($connection->query($sql) === TRUE)
        {
            echo "<h1>Record added</h1>";
            echo "<p><a href='scp-002.php'>Home</a></p>";
        }
        else
        {
            echo "<h1>Error: Record not added</h1>";
            echo "<p>{$connection->error()}</p>";
            echo "<p><a href='scp-002.php'>Home</a></p>";
        }
    }
    
    if(isset($_POST['update']))
    {
        $id = $_POST['id'];
        $pg = $_POST['pg'];
        $h1 = $_POST['h1'];
        $h2 = $_POST['h2'];
        $p1 = htmlspecialchars($_POST['p1']);
        $p1 = $connection->real_escape_string($p1);
        $p2 = htmlspecialchars($_POST['p2']);
        $p2 = $connection->real_escape_string($p2);
        $images = $_POST['images'];
        
        $update = "update pages set pg='$pg', h1='$h1', h2='$h2', p1='$p1', p2='$p2', images='$images'
        where id='$id'";
        
        if($connection->query($update) === TRUE)
        {
            echo "<h1>Record Updated</h1>";
            echo "<p><a href='scp-002.php' class='btn btn-success'>Home</a></p>";
        }
        else
        {
            echo "<h1>Error: Record not updated</h1>";
            echo "<p>{$connection->error()}</p>";
            echo "<p><a href='scp-002.php' class='btn btn-danger'>Home</a></p>";
        }
    }
    
    if(isset($_GET['delete']))
    {
        $id = $_GET['delete'];
        
        //create delete sql command
        $del = "delete from pages where id=$id";
        
        //run above sql command and then display appropriate success or error messages
        if($connection->query($del) === TRUE)
        {
            echo "<h1>Record was deleted</h1> 
            <p><a href='scp-002.php'>Return to Home Page</a></p>";
        }
        else
        {
            echo "
                <h1>There was an error deleting this record</h1>
                <p>{$connection->error()}</p>
                <p><a href='scp-002.php'>Back to Home Page</a></p>
            
            ";
        }
        
    }

?>