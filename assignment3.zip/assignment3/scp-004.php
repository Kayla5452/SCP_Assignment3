<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Slab&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>SCP Foundation SCP-004</title>
  </head>
  <body class="container">
      <?php include 'db.php'; ?>

    <nav class="navbar navbar-dark bg-dark">

        <h1 class="bg-dark">SCP Foundation</h1>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="scp-002.php">SCP-002</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="scp-003.php">SCP-003</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="scp-004.php">SCP-004</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="scp-005.php">SCP-005</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="scp-006.php">SCP-006</a>
                </li>

                <?php foreach($record as $menu): ?>
            
                    <li class="nav-item">
                        
                        <a href="index.php?page='<?php echo $menu['pg']; ?>'" class="nav-link"><?php echo $menu['pg']; ?></a>
                        
                    </li>
            
                <?php endforeach; ?>
                
                <div class="dropdown-divider"></div>

                <li class="nav-item">
                    <a class="nav-link" href="create.php">Create new record</a>
                </li>
            </ul>
        </div>
    </nav>
        <div class="card bg-secondary" style="margin-top: 5px;">
            <div class="card-header bg-dark">
                <h2>SCP-004</h2>
            </div>
            <div class="card-body ">
                <h3><b>Item #: </b>SCP-004</h3>
                <h4><b>Object Class: </b>Euclid</h4>

                <hr class=" bg-dark">
                <h5>Special Containment Procedures:</h5>
                <p>When handling items SCP-004-2 through SCP-004-13, proper procedure is vital. The items are not permitted to be moved off-site unless accompanied by two Level 4 security personnel. Under no circumstances should any other component of SCP-004 be taken through SCP-004-1. The effects of doing so are as yet unknown, and the current cost of experimentation makes further research impractical. Should any of the objects contained within SCP-004-1 breach containment, or the facility be breached, the keys must be brought inside and the door closed prior to activation of Site 62’s on-site warhead. Unauthorized removal of keys from the testing area is grounds for immediate termination.</p>
                <p>Level 1 clearance is required for basic access to SCP-004-1; Level 4 clearance is required for use of SCP-004-2 to -13.</p>
                <h5>Description:</h5>
                <p>SCP-004 consists of an old wooden barn door (SCP-004-1) and a set of twelve rusted steel keys (SCP-004-2 through SCP-004-13). The door itself is the entrance to an abandoned factory in <span class="text-danger">[DATA EXPUNGED]</span>.</p>
            </div>
            <img src="images/SCP-004.jpg" alt="SCP-004 Door">
            <div class="card-body">
                <h5>Chronological History</h5>
                    <div class="headers-list">
                      <div class="list-group" id="list-tab" role="tablist">
                        <a class="list-group-item list-group-item-action list-group-item-dark active" id="list-one-list" data-toggle="list" href="#list-one" role="tab" aria-controls="list-one">07/02/1949</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-two-list" data-toggle="list" href="#list-two" role="tab" aria-controls="list-two">07/03/1949</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-three-list" data-toggle="list" href="#list-three" role="tab" aria-controls="list-three">07/04/1949</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-four-list" data-toggle="list" href="#list-four" role="tab" aria-controls="list-four">07/16/1949</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-five-list" data-toggle="list" href="#list-five" role="tab" aria-controls="list-five">08/02/1949</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-six-list" data-toggle="list" href="#list-six" role="tab" aria-controls="list-six">12/01/1950</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-seven-list" data-toggle="list" href="#list-seven" role="tab" aria-controls="list-seven">07/02/19██</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-eight-list" data-toggle="list" href="#list-eight" role="tab" aria-controls="list-eight">07/04/19██</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-nine-list" data-toggle="list" href="#list-nine" role="tab" aria-controls="list-nine">03/21/1999</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-ten-list" data-toggle="list" href="#list-ten" role="tab" aria-controls="list-ten">04/21/1999</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-eleven-list" data-toggle="list" href="#list-eleven" role="tab" aria-controls="list-eleven">09/25/2000</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-twelve-list" data-toggle="list" href="#list-twelve" role="tab" aria-controls="list-twelve">01/25/2001</a>
                        <a class="list-group-item list-group-item-action list-group-item-dark" id="list-thirteen-list" data-toggle="list" href="#list-thirteen" role="tab" aria-controls="list-thirteen">08/14/2003</a>
                      </div>
                    </div>
                    <div class="content-list">
                      <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="list-one" role="tabpanel" aria-labelledby="list-one-list">A group of three juveniles trespassing on federal property near ██████████ find the door. According to their testimony, they found a set of rusted keys in an iron lockbox and determined what door the keys unlock. The juveniles are taken into custody after they contact Sheriff █████████████████ when one of their friends (SCP-004-CAS01) goes missing.</div>
                        <div class="tab-pane fade" id="list-two" role="tabpanel" aria-labelledby="list-two-list">Local authorities find the severed right hand of SCP-004-CAS01 eight kilometers from SCP-004-1. Other parts of SCP-004-CAS01's body are found scattered as far as 32 km from the factory. Under interrogation, the apprehended juveniles tell authorities that upon opening the door with one of the keys, SCP-004-CAS01 was torn into several pieces, each of which disappeared. At this point, the SCP Foundation takes over the investigation.</div>
                        <div class="tab-pane fade" id="list-three" role="tabpanel" aria-labelledby="list-three-list">SCP Agent █████ obtains the keys from the local authorities to begin testing. Tests show that SCP-004-2 through SCP-004-13 all fit into a single lock on the large barred door. 12 Class D personnel are assigned to test the effects of the door. Of the twelve test subjects each trying a different key to enter the room, only two survive. Opening the door with any key except SCP-004-7 or SCP-004-12 caused the test subjects to be torn apart in multiple directions; however, no dismembered parts were found until later. At the time of writing, only two parts of each subject have been recovered (with the exception of the subject using SCP-004-█, whose pieces were scattered in close proximity). The others have, for all intents and purposes, vanished from existence.<br>Of the two surviving subjects, only one (having used SCP-004-7) returned unharmed. The other came back in a near-catatonic state, able only to remove himself from the room and then collapse on the floor, and had to be restrained to prevent him from gouging out his eyes (see Appendix A: Mental Health Effects of SCP-004). The subject using SCP-004-7 said that he had entered a large room, impossibly big for the size of the attached building. After his exit, SCP-004-1 was propped open and an armed squad of Level 3 personnel entered. The size of the room is impossible to measure and the door frame and the individuals in the room are the only part of the room that can be felt or illuminated.</div>
                        <div class="tab-pane fade" id="list-four" role="tabpanel" aria-labelledby="list-four-list">The juvenile suspects and Sheriff █████████████████ are terminated.</div>
                        <div class="tab-pane fade" id="list-five" role="tabpanel" aria-labelledby="list-five-list">█████████████████ is declared a hazardous area "due to unexploded ordnance" and fences erected in order to prevent civilian ingress. Tests to determine safety of exposure to environment behind SCP-004-1 begin.</div>
                        <div class="tab-pane fade" id="list-six" role="tabpanel" aria-labelledby="list-six-list">Space-time anomalies resulting from exposure to SCP-004 are confirmed. Testing is suspended until further notice.</div>
                        <div class="tab-pane fade" id="list-seven" role="tabpanel" aria-labelledby="list-seven-list">The unaccounted-for remains of SCP-004-CAS01 appear unexpectedly outside SCP-004-1. Despite being killed decades before, the remains of SCP-004-CAS01 are not decomposed in any manner and are still warm to the touch. Blood remains uncoagulated. The remains are remanded for testing.</div>
                        <div class="tab-pane fade" id="list-eight" role="tabpanel" aria-labelledby="list-eight-list">The unaccounted-for remains of one of the twelve (12) original test subjects appear in similar manner to those of SCP-004-CAS01. The remains have been designated SCP-004-CAS02. Records suggest that both SCP-004-CAS01 and CAS02 used SCP-004-██.</div>
                        <div class="tab-pane fade" id="list-nine" role="tabpanel" aria-labelledby="list-nine-list">With the massive proliferation of nuclear weapons and World War III only ██ years away, construction has begun on a site inside SCP-004-1. The site is to stock supplies for ███████ person-days.</div>
                        <div class="tab-pane fade" id="list-ten" role="tabpanel" aria-labelledby="list-ten-list">█████████████████ has ordered the site inside SCP-004-1 to be expanded to include emergency storage for all mobile SCP-███ specimens and a ██-petabyte database for the storage of all SCP data. The facility is now referred to as Site-62.</div>
                        <div class="tab-pane fade" id="list-eleven" role="tabpanel" aria-labelledby="list-eleven-list">Site-62 is operational. Labs and containment units are complete and can contain the most dangerous specimens. Backup of the SCP database has begun.</div>
                        <div class="tab-pane fade" id="list-twelve" role="tabpanel" aria-labelledby="list-twelve-list">Due to time anomalies (see “Space-Time Anomalies” below), all personnel working at Site-62 are now required to reside on-site permanently. Families of personnel are to be informed that loved ones perished in an industrial accident. Cloned bodies have been prepared for funeral.</div>
                        <div class="tab-pane fade" id="list-thirteen" role="tabpanel" aria-labelledby="list-thirteen-list">Massive power outage across Northeast United States and through Canada. Due to the initial failure of multiple SCP generators, Site-62 was without power for fifty-three (53) minutes. During those fifty-three (53) minutes, those on site were completely without any source of light. They reported "sensing" creatures and people, although no abnormal entities could be seen or felt. Selected facility personnel were allowed to read ████████████ (Appendix A) and said the creatures "sensed" were of humanoid size but otherwise similar to the massive green creature described.</div>
                      </div>
                    </div>
                    <div class="clearfix"></div>
                <br>
                <h5>Space-Time Anomalies</h5>
                <p>SCP-004 seems to propagate spatiotemporal anomalies. Personnel leaving the facility report losing time. Those who have been in the site for weeks insist that they had only been in the facility for several days, and records of work completed and supplies consumed support their claims. Other temporal anomalies involve SCP-004-2 through -13, especially the reappearance of SCP-004-CAS01 and SCP-004-CAS02 exactly ██ years after using SCP-004-██. ████████████████████ has been assigned to investigate all aspects of these time anomalies. Spatial anomalies include the impossibly large dimensions of the area opened by SCP-004-7. Similarly, the 2003 blackout incident suggests that there exists an alternate plane of existence within the same space that Site-62 occupies.</p>
                <h5>Additional Notes</h5>
                <p>Testing on SCP-004 reveals that ten of the keys open SCP-004-1 on a dimension where the laws of physics and topology are significantly different than those of our home dimension. Test subjects meeting these hostile conditions are torn apart, their body parts deposited in various locations, only three of which have been verified to be on Earth. Material deposited at two of these points appears immediately; material deposited at the third appears exactly ██ years into the future. The other seven locations are currently unknown.</p>
                <p>Current testing focuses on two avenues of research. The first is finding ways to survive SCP-004’s hostile topologies. The second <span class="text-danger">[DATA EXPUNGED]</span> suggest that SCP-004-2 through -13 may open doors other than SCP-004-1.</p>
                <h5>Appendix A: Mental Health Effects of SCP-004-12</h5>
                <p>All Class D personnel using SCP-004-12 return in a catatonic state, unable to speak. Some may have enough energy left to try to claw out their eyes. Of the 16 subjects, only 4 have survived. Only one has regained speech, following long-term psychotherapy. He was able to tell the psychiatrist that he saw a massive green creature, so large that much of its body extended beyond his field of view. He reported innate fear and sudden recognition, “as if it were something buried deep in [his] primal fears,” and forced implantation of “incomprehensible” memories. Subject displays acute anterograde and retrograde amnesia.</p>
                <h5>Appendix B: Additional Information</h5>
                <p><b>Item #:</b> SCP-004-14 SCP-004-14</p>
                <p><b>Date of Discovery:</b> 09/02/1950</p>
                <p><b>Origin of Object:</b> Object was discovered elsewhere in factory area, in the previously undiscovered manager's office.</p>
                <p><b>Description:</b> Object appears as a large, unvarnished wooden box. The box may be unlocked by the "safe" key, SCP-004-7, as well as five of the "unsafe" keys (see Document SCP-004-1).</p>
                <p>Upon unlocking SCP-004-14 with SCP-004-7, the box opens automatically on hinges. The volume of the space inside is precisely five times greater than the outer dimensions imply. Items placed within while the lid remains open do not affect the weight or any other properties of the box. When the lid is closed and locked, however, all items inside vanish irretrievably. Personnel locked inside the box are also irretrievable, although losing personnel in this fashion appears to affect significantly the dreams experienced by <span class="text-danger">[DATA EXPUNGED]</span>.</p>
            </div>
          </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>