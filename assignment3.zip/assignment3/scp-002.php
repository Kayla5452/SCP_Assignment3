<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Slab&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>SCP Foundation SCP-002</title>
  </head>
  <body class="container">

    <?php include 'db.php'; ?>

        <nav class="navbar navbar-dark bg-dark">

            <h1 class="bg-dark">SCP Foundation</h1>
                 
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="scp-002.php">SCP-002</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-003.php">SCP-003</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-004.php">SCP-004</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-005.php">SCP-005</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-006.php">SCP-006</a>
                    </li>

                    <?php foreach($record as $menu): ?>
                  
                        <li class="nav-item">
                            
                            <a href="index.php?page='<?php echo $menu['pg']; ?>'" class="nav-link"><?php echo $menu['pg']; ?></a>
                            
                        </li>
                  
                    <?php endforeach; ?>
                    
                    <div class="dropdown-divider"></div>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="create.php">Create a new record</a>
                    </li>
                    
                </ul>
            </div>
        </nav>
        <div class="card bg-secondary" style="margin-top: 5px;">
            <div class="card-header bg-dark">
                <h2>SCP-002</h2>
            </div>
            <div class="card-body">
                <h3><b>Item #: </b>SCP-002</h3>
                <h4><b>Object Class: </b>Euclid</h4>
                <hr class=" bg-dark">
            </div>
            <img class="pt-0" src="images/SCP-002.jpg" alt="SCP-002">
            <div class="card-body">
                <h5>Special Containment Procedures:</h5>
                <p>SCP-002 is to remain connected to a suitable power supply at all times, to keep it in what appears to be a recharging mode. In case of electrical outage, the emergency barrier between the object and the facility is to be closed and the immediate area evacuated. Once facility power is re-established, alternating bursts of X-ray and ultraviolet light must strobe the area until SCP-002 is re-affixed to the power supply and returned to recharging mode. Containment area is to be kept at negative air pressure at all times.</p>
                <p>Teams including a minimum of two (2) members are required within 20 meters of SCP-002 or its containment area. Personnel should maintain physical contact with one another at all times to confirm there is another person present, as perception may be dulled, skewed, or influenced by proximity to the object.</p>
                <p>No personnel below Level 3 are permitted within SCP-002. This requirement may be waived via written authorization from two (2) off-site Level 4 administrators. Command staff issued such a waiver must be escorted by at least five (5) Level 3 Security personnel for the duration of their contact and must temporarily surrender their rank and security clearance. Following contact, command staff will be escorted at least 5 km from SCP-002 to undergo a seventy-two (72)-hour quarantine and psychological evaluation. If deemed fit for return to duty by psych staff, rank and security clearance may be restored when quarantine expires.</p>
                <h5>Description:</h5>
                <p>SCP-002 resembles a tumorous, fleshy growth with a volume of roughly 60 m³ (or 2000 ft³). An iron valve hatch on one side leads to its interior, which appears to be a standard low-rent apartment of modest size. One wall of the room possesses a single window, though no such opening is visible from the exterior. The room contains furniture which, upon close examination, appears to be sculpted bone, woven hair, and various other biological substances produced by the human body. All matter tested thus far show independent or fragmented DNA sequences for each object in the room.</p>
                <p>Refer to the Mulhausen Report [cross-ref:document00.023.603] for details related to object's discovery.</p>
                <h5>Reference:</h5>
                <p>To date, subject has been responsible for the disappearances of seven personnel. It has also in its time at the facility further furnished itself with two lamps, a throw rug, a television, a radio, a beanbag chair, three books in an unknown language, four children's toys, and a small potted plant. Tests with a variety of lab animals including higher primates have failed to provoke a response in SCP-002. Cadavers as well fail to produce any effect. Whatever process the subject uses to convert organic matter into furnishings is apparently only facilitated by the introduction of living humans.</p>
                <h6>Mulhausen Report docid:00.023.603</h6>
                <p><code class="text-warning">The following is a brief report detailing the discovery of SCP-002</code></p>
                <p><code class="text-warning">Subject was discovered in a small crater in northern Portugal where it struck the Earth from orbit. Encased in a shell of thick rock, the fleshy exterior of the object was exposed by the impact. A native farmer happened upon the site and reported his findings to the village elder. Subject gained SCP attention when a Level 4 agent posted in the area detected a small radioactive anomaly generated by the object.</code></p>
                <p><code class="text-warning">A collection squad of SCP security personnel led by General Mulhausen was immediately dispatched to the area where they quickly secured the subject in a large container and performed initial testing with subjects recruited from the nearby village. Three men individually sent into the structure subsequently disappeared. Upon discovering this deadly property of the subject, General Mulhausen issued a Level 4a Termination Order of any witnesses (roughly 1/3 of the village) to ensure no outside knowledge of the object and initiated its transport to SCP facility <span class="text-danger">[DATA EXPUNGED]</span>.</code></p>
                <p><code class="text-warning">During preparation for transport, four SCP security personnel were inexplicably drawn inside the object where they too immediately disappeared. Following inspection, it appeared as if the object had "grown" several new furnishings and was beginning to look like the interior of an apartment room. General Mulhausen immediately ordered the requisition of several Class III HAZMAT suits for the remaining security team members, who proceeded to lift the container onto a waiting freight ship for transport to the SCP containment facility.</code></p>
                <p><code class="text-danger">[DATA EXPUNGED]</code></p>
                <p><code class="text-danger">[DATA EXPUNGED]</code></p>
                <p><code class="text-warning">Following the termination of General Mulhausen, SCP-002 was re-secured by SCP staff and brought into special containment in <span class="text-danger">[CLASSIFIED]</span> where it currently resides. Staff with clearance below Level 3 have been denied access to the SCP-002 container without prior approval of at least two Level 4 staff after the Mulhausen incident.</code></p>
            </div>
          </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>