<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Slab&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Update record</title>
  </head>
  <body class="container">
  <?php include 'db.php'; ?>

        <nav class="navbar navbar-dark bg-dark">

            <h1 class="bg-dark">SCP Foundation</h1>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="scp-002.php">SCP-002</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-003.php">SCP-003</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-004.php">SCP-004</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-005.php">SCP-005</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="scp-006.php">SCP-006</a>
                    </li>

                    <?php foreach($record as $menu): ?>
                  
                        <li class="nav-item">
                            
                            <a href="index.php?page='<?php echo $menu['pg']; ?>'" class="nav-link"><?php echo $menu['pg']; ?></a>
                            
                        </li>
                  
                    <?php endforeach; ?>

                    <div class="dropdown-divider"></div>

                    <li class="nav-item active">
                        <a class="nav-link" href="create.php">Create new record</a>
                    </li>
                </ul>
            </div>
        </nav>
    
      <div class="card bg-secondary" style="margin-top: 5px;">
          <div class="card-header bg-dark">
              <h2>Update record</h2>
          </div>
          <div class="card-body">
              <?php
              
                  include 'db.php';
                  
                  $id = $_GET['update'];
                  
                  $record = $connection->query("select * from pages where id='$id'") or die($connection->error());
                  
                  $row = $record->fetch_assoc();
              
              ?>
              
              <form class="form-group" action="db.php" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <label>Update Page Name:</label>
                  <br>
                  <input type="text" name="pg" placeholder="Write Page Name here" class="form-control" value="<?php echo $row['pg']; ?>">
                  <br>
                  <label>Update Item Name:</label>
                  <br>
                  <input type="text" name="h1" placeholder="Write Main Item Name here" class="form-control" value="<?php echo $row['h1']; ?>">
                  <br>
                  <label>Update Object Class:</label>
                  <br>
                  <input type="text" name="h2" placeholder="Write Object Class here" class="form-control" value="<?php echo $row['h2']; ?>">
                  <br>
                  <label>Update Special Contaiment Procedures:</label>
                  <br>
                  <input type="text" name="p1" placeholder="Write Special Containment Procedures here" class="form-control" value="<?php echo $row['p1']; ?>">
                  <br>
                  <label>Update Description:</label>
                  <br>
                  <input type="text" name="p2" placeholder="Write Description here" class="form-control" value="<?php echo $row['p2']; ?>">
                  <br>
                  <label>Update image address:</label>
                  <br>
                  <input type="text" name="images" placeholder="e.g images/pic.jpg" class="form-control" value="<?php echo $row['images']; ?>">
                  <br>
                  <input type="submit" name="update" class="btn btn-primary" value="Update">
                  
              </form>
          </div>
        </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>